(function () {
    'use strict';

    // Clicking the extension icon should open the options page
    chrome.runtime.openOptionsPage(function () {
        window.close();
    });

}());
