(function () {
    'use strict';

    var runtime = (function () {
        return (
        // Chrome
        (chrome === null || chrome === void 0 ? void 0 : chrome.runtime) || (
        // Firefox
        //@ts-ignore
        window === null || 
        // Firefox
        //@ts-ignore
        window === void 0 ? void 0 : 
        // Firefox
        //@ts-ignore
        window.runtime)
            || (
            // Firefox content script
            //@ts-ignore
            browser === null || 
            // Firefox content script
            //@ts-ignore
            browser === void 0 ? void 0 : 
            // Firefox content script
            //@ts-ignore
            browser.runtime));
    })();

    var storage = (function () {
        var _a;
        return (
        // Chrome
        ((_a = window === null || window === void 0 ? void 0 : window.chrome) === null || _a === void 0 ? void 0 : _a.storage) || (
        // Firefox
        //@ts-ignore
        window === null || 
        // Firefox
        //@ts-ignore
        window === void 0 ? void 0 : 
        // Firefox
        //@ts-ignore
        window.storage)
            || (
            // Firefox content script
            //@ts-ignore
            browser === null || 
            // Firefox content script
            //@ts-ignore
            browser === void 0 ? void 0 : 
            // Firefox content script
            //@ts-ignore
            browser.storage));
    })();

    var browser$1 = /*#__PURE__*/Object.freeze({
        __proto__: null,
        runtime: runtime,
        storage: storage
    });

    console.log(browser$1);
    var Color = {
        check: parseInt('0x8359EE'),
        save: parseInt('0x6CBF5B'),
        roll: parseInt('0xF5A623'),
        'to hit': parseInt('0x1B9AF0'),
        damage: parseInt('0xD54F4F'),
        heal: parseInt('0x6CBF5B')
    };
    var Abilities = {
        str: 'Strength',
        dex: 'Dexterity',
        con: 'Constitution',
        int: 'Intelligence',
        wis: 'Wisdom',
        cha: 'Charisma'
    };
    var characterName;
    var characterAvatarURL;
    var sendHook = function (embed) {
        var headers = new Headers();
        headers.set('Content-Type', 'application/json');
        embed['timestamp'] = new Date().toISOString();
        console.info('BeyondDiscord: Attempting to send roll', embed);
        return new Promise(function (resolve) {
            storage.sync.get(function (data) {
                if (data.disabled) {
                    console.info('BeyondDiscord: Extension disabled. Interrupting.');
                    return;
                }
                if (data.hookURL === undefined) {
                    console.info('BeyondDiscord: No webhook found. Interrupting.');
                    return;
                }
                resolve(fetch(data.hookURL + '?wait=true', {
                    method: 'POST',
                    mode: 'cors',
                    cache: 'no-cache',
                    headers: headers,
                    body: JSON.stringify({
                        embeds: [
                            embed
                        ],
                        username: characterName,
                        avatar_url: characterAvatarURL
                    })
                }));
            });
        })
            .then(function (res) {
            console.info('BeyondDiscord: Successfully sent roll', res);
        })["catch"](function (err) {
            console.error('BeyondDiscord: Failed to send roll', err);
        });
    };
    var handleRoll = function (roll) {
        sendHook({
            color: Color[roll.type] || 0,
            title: (Abilities[roll.ability] || roll.ability) + " *" + roll.type + "*",
            description: "**" + roll.rollString + "** " +
                (roll.rollMod ? "*" + roll.rollMod + "*" : '') +
                '\n```haskell\n' +
                (roll.rollResults + " = " + roll.rollSum + "\n") +
                '```',
            fields: []
        });
    };
    var parseRoll = function ($diceResult) {
        var _a;
        var type = $diceResult
            .querySelector('.dice_result__rolltype')
            .innerHTML;
        var ability = $diceResult
            .querySelector('.dice_result__info__rolldetail')
            .innerHTML;
        ability = ability.substring(0, ability.length - 2); // Remove trailing :
        var rollResults = $diceResult
            .querySelector('.dice_result__info__breakdown')
            .innerHTML;
        var rollString = $diceResult
            .querySelector('.dice_result__info__dicenotation')
            .innerHTML
            .replace(/kh1|kl1/img, ''); // Removing garbage added by advantage or disadvantage rolls
        var rollSum = $diceResult
            .querySelector('.dice_result__total-result')
            .innerHTML;
        var rollMod = ((_a = $diceResult
            .querySelector('.dice_result__total-header')) === null || _a === void 0 ? void 0 : _a.innerHTML) || null;
        return {
            type: type,
            ability: ability,
            rollString: rollString,
            rollResults: rollResults,
            rollSum: rollSum,
            rollMod: rollMod
        };
    };
    var findLatestRoll = function ($notifyLayout) {
        var $notifyBars = $notifyLayout.querySelectorAll('.noty_bar');
        var $notifyBody = $notifyBars
            .item($notifyBars.length - 1)
            .querySelector('.noty_body');
        var $diceResult = $notifyBody.querySelector('.dice_result');
        return $diceResult;
    };
    var handlePotentialRoll = function ($notifyLayout) {
        var $roll = findLatestRoll($notifyLayout);
        if ($roll.getAttribute('beyondDiscord_STATUS') === 'sent')
            return;
        $roll.setAttribute('beyondDiscord_STATUS', 'sent');
        var roll = parseRoll($roll);
        handleRoll(roll);
    };
    // Step 1: Create a new MutationObserver object
    var observer = new MutationObserver(function (muts) {
        var mut = muts[0];
        handlePotentialRoll(mut.target);
    });
    var notifyLayoutObserver = new MutationObserver(function (muts) {
        var notifyField = muts[0].target
            .querySelector('.noty_layout');
        if (notifyField === null)
            return;
        // Get character information
        characterName = document.querySelector('.ddbc-character-name')
            .innerHTML;
        var $characterAvatar = document.querySelector('.ddbc-character-avatar__portrait');
        characterAvatarURL = $characterAvatar.style.backgroundImage
            .substring(5, $characterAvatar.style.backgroundImage.length - 2);
        // Handle initial roll
        handlePotentialRoll(notifyField);
        // Step 2: Observe a DOM node with the observer as callback
        try {
            // Disconnect observer if there is one
            observer.disconnect();
        }
        catch (_a) { }
        observer.observe(notifyField, {
            childList: true
        });
    });
    notifyLayoutObserver.observe(document.querySelector('body'), {
        childList: true
    });

}());
