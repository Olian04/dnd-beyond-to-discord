(function () {
    'use strict';

    var useFeature = function (key) {
        try {
            if (chrome[key]) {
                return chrome[key];
            }
        }
        catch (_a) { }
        try {
            //@ts-ignore
            if (browser[key]) {
                //@ts-ignore
                return browser[key];
            }
        }
        catch (_b) { }
        try {
            //@ts-ignore
            if (window[key]) {
                //@ts-ignore
                return window[key];
            }
        }
        catch (_c) { }
    };

    var storage = useFeature('storage');
    useFeature('runtime');
    useFeature('tabs');

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __spreadArray(to, from, pack) {
        if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
            if (ar || !(i in from)) {
                if (!ar) ar = Array.prototype.slice.call(from, 0, i);
                ar[i] = from[i];
            }
        }
        return to.concat(ar || Array.prototype.slice.call(from));
    }

    var sensitiveData = { hookURL: null };
    var omitSensitiveData = function (obj) { return Object.keys(obj)
        .filter(function (k) { return !(k in sensitiveData); })
        .reduce(function (res, k) {
        var _a;
        return (__assign(__assign({}, res), (_a = {}, _a[k] = obj[k], _a)));
    }, {}); };

    var limitStoredLogs = function (numberOfLogsToKeep) { return __awaiter(void 0, void 0, void 0, function () {
        var logs, logsToKeep;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, storage.local.get('logs')];
                case 1:
                    logs = (_a.sent()).logs;
                    logsToKeep = logs.slice(logs.length - numberOfLogsToKeep);
                    return [2 /*return*/, storage.local.set({
                            logs: logsToKeep
                        })];
            }
        });
    }); };
    var processMessageParts = function (parts) { return parts.map(function (v) {
        if (typeof v === 'object') {
            v = omitSensitiveData(v);
            try {
                return JSON.stringify(v);
            }
            catch (_a) { }
        }
        return String(v);
    }).join(' '); };
    var storeLog = function (log) { return __awaiter(void 0, void 0, void 0, function () {
        var logs;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, storage.local.get('logs')];
                case 1:
                    logs = (_a.sent()).logs;
                    return [4 /*yield*/, storage.local.set({
                            logs: __spreadArray(__spreadArray([], (logs !== null && logs !== void 0 ? logs : []), true), [log], false)
                        })];
                case 2:
                    _a.sent();
                    limitStoredLogs(100);
                    return [2 /*return*/];
            }
        });
    }); };
    var useLogger = function (source) { return ({
        info: function () {
            var messageParts = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                messageParts[_i] = arguments[_i];
            }
            return storeLog({
                type: 'info',
                source: source,
                timestamp: Date.now(),
                content: processMessageParts(messageParts)
            });
        },
        error: function () {
            var messageParts = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                messageParts[_i] = arguments[_i];
            }
            return storeLog({
                type: 'error',
                source: source,
                timestamp: Date.now(),
                content: processMessageParts(messageParts)
            });
        },
        warn: function () {
            var messageParts = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                messageParts[_i] = arguments[_i];
            }
            return storeLog({
                type: 'warning',
                source: source,
                timestamp: Date.now(),
                content: processMessageParts(messageParts)
            });
        }
    }); };

    var logger = useLogger('contentScript');
    var Color = {
        check: parseInt('0x8359EE'),
        save: parseInt('0x6CBF5B'),
        roll: parseInt('0xF5A623'),
        'to hit': parseInt('0x1B9AF0'),
        damage: parseInt('0xD54F4F'),
        heal: parseInt('0x6CBF5B')
    };
    var Abilities = {
        str: 'Strength',
        dex: 'Dexterity',
        con: 'Constitution',
        int: 'Intelligence',
        wis: 'Wisdom',
        cha: 'Charisma'
    };
    var characterName;
    var characterAvatarURL;
    var sendHook = function (embed) {
        var headers = new Headers();
        headers.set('Content-Type', 'application/json');
        embed['timestamp'] = new Date().toISOString();
        return new Promise(function (resolve) {
            storage.sync.get(function (data) {
                if (data.disabled) {
                    logger.info('Interrupting roll because extension is disabled.');
                    return;
                }
                if (typeof data.hookURL !== 'string' || data.hookURL.trim().length === 0) {
                    logger.info('Interrupting roll because no webhook was found.');
                    return;
                }
                logger.info('Attempting to send roll', embed);
                resolve(fetch(data.hookURL + '?wait=true', {
                    method: 'POST',
                    mode: 'cors',
                    cache: 'no-cache',
                    headers: headers,
                    body: JSON.stringify({
                        embeds: [
                            embed
                        ],
                        username: characterName,
                        avatar_url: characterAvatarURL
                    })
                }));
            });
        })
            .then(function (resp) {
            if (resp.ok) {
                logger.info("Successfully sent roll (response code: ".concat(resp.status, ")"));
            }
            else {
                logger.error("Failed to send roll (response code: ".concat(resp.status, ")"));
            }
        })["catch"](function (err) {
            logger.error('Failed to send roll', err);
        });
    };
    var handleRoll = function (roll) {
        sendHook({
            color: Color[roll.type] || 0,
            title: "".concat(Abilities[roll.ability] || roll.ability, " *").concat(roll.type, "*"),
            description: "**".concat(roll.rollString, "** ") +
                (roll.rollMod ? "*".concat(roll.rollMod, "*") : '') +
                '\n```haskell\n' +
                "".concat(roll.rollResults, " = ").concat(roll.rollSum, "\n") +
                '```',
            fields: []
        });
    };
    var parseDiceResults = function ($diceResult) {
        var _a;
        try {
            var type = $diceResult
                .querySelector('.dice_result__rolltype')
                .innerHTML;
            var ability = $diceResult
                .querySelector('.dice_result__info__rolldetail')
                .innerHTML;
            ability = ability.substring(0, ability.length - 2); // Remove trailing :
            var rollResults = $diceResult
                .querySelector('.dice_result__info__breakdown')
                .innerHTML;
            var rollString = $diceResult
                .querySelector('.dice_result__info__dicenotation')
                .innerHTML
                .replace(/kh1|kl1/img, ''); // Removing garbage added by advantage or disadvantage rolls
            var rollSum = $diceResult
                .querySelector('.dice_result__total-result')
                .innerHTML;
            var rollMod = ((_a = $diceResult
                .querySelector('.dice_result__total-header')) === null || _a === void 0 ? void 0 : _a.innerHTML) || null;
            return {
                type: type,
                ability: ability,
                rollString: rollString,
                rollResults: rollResults,
                rollSum: rollSum,
                rollMod: rollMod
            };
        }
        catch (err) {
            logger.error('Failed to parse dice results', err);
            throw err;
        }
    };
    var findLatestRoll = function ($notifyLayout) {
        try {
            var $notifyBars = $notifyLayout.querySelectorAll('.noty_bar');
            var $notifyBody = $notifyBars
                .item($notifyBars.length - 1)
                .querySelector('.noty_body');
            var $diceResult = $notifyBody.querySelector('.dice_result');
            return $diceResult;
        }
        catch (err) {
            logger.error('Failed to find latest roll', err);
            throw err;
        }
    };
    var handlePotentialRoll = function ($notifyLayout) {
        try {
            var $roll = findLatestRoll($notifyLayout);
            if ($roll.getAttribute('beyondDiscord_STATUS') === 'sent')
                return;
            $roll.setAttribute('beyondDiscord_STATUS', 'sent');
            var roll = parseDiceResults($roll);
            handleRoll(roll);
        }
        catch (err) {
            logger.error('Failed to handle potential roll', err);
            throw err;
        }
    };
    var extractCharacterInformation = function () {
        try {
            var characterName_1 = document.querySelector('.ddbc-character-name').innerHTML;
            var $characterAvatar = document.querySelector('.ddbc-character-avatar__portrait');
            var characterAvatarURL_1 = $characterAvatar.style.backgroundImage
                .substring(5, $characterAvatar.style.backgroundImage.length - 2);
            return {
                characterName: characterName_1,
                characterAvatarURL: characterAvatarURL_1
            };
        }
        catch (err) {
            logger.error('Failed to extract character information');
            throw err;
        }
    };
    // Step 1: Create a new MutationObserver object
    var observer = new MutationObserver(function (muts) {
        var mut = muts[0];
        handlePotentialRoll(mut.target);
    });
    var notifyLayoutObserver = new MutationObserver(function (muts) {
        var notifyField = muts[0].target
            .querySelector('.noty_layout');
        if (notifyField === null)
            return;
        // Get character information
        var characterInfo = extractCharacterInformation();
        characterName = characterInfo.characterName;
        characterAvatarURL = characterInfo.characterAvatarURL;
        logger.info("Found character \"".concat(characterName, "\""));
        // Handle initial roll
        handlePotentialRoll(notifyField);
        // Step 2: Observe a DOM node with the observer as callback
        try {
            // Disconnect observer if there is one
            observer.disconnect();
        }
        catch (_a) { }
        observer.observe(notifyField, {
            childList: true
        });
    });
    notifyLayoutObserver.observe(document.querySelector('body'), {
        childList: true
    });

})();
