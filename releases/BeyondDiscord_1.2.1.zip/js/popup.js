(function () {
    'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __spreadArray(to, from, pack) {
        if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
            if (ar || !(i in from)) {
                if (!ar) ar = Array.prototype.slice.call(from, 0, i);
                ar[i] = from[i];
            }
        }
        return to.concat(ar || Array.prototype.slice.call(from));
    }

    function createCommonjsModule(fn) {
      var module = { exports: {} };
    	return fn(module, module.exports), module.exports;
    }

    var hash = createCommonjsModule(function (module, exports) {
    /* tslint:disable:no-bitwise */
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.objHash = void 0;
    /**
     * Source: https://gist.github.com/jlevy/c246006675becc446360a798e2b2d781
     * This is a simple, *insecure* hash that's short, fast, and has no dependencies.
     * For algorithmic use, where security isn't needed, it's way simpler than sha1 (and all its deps)
     * or similar, and with a short, clean (base 36 alphanumeric) result.
     * Loosely based on the Java version; see
     * https://stackoverflow.com/questions/6122571/simple-non-secure-hash-function-for-javascript
     */
    const hashString = (str) => {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = (hash << 5) - hash + char;
            hash &= hash; // Convert to 32bit integer
        }
        return new Uint32Array([hash])[0].toString(36);
    };
    // This is used to ensure that no hash begins with a number, since CSS selectors cant start with numbers
    const prefix = 'brynja-';
    const objHash = (obj) => prefix + hashString(JSON.stringify(obj));
    exports.objHash = objHash;
    });

    var builder = createCommonjsModule(function (module, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.buildNode = exports.newVNode = void 0;

    /* istanbul ignore next */ // istanbul doesn't recognize this function as covered by tests, even though it clearly is
    const newVNode = (ctx = {}) => (Object.assign({ tag: '', value: null, text: '', events: {}, props: {}, children: [] }, ctx));
    exports.newVNode = newVNode;
    const naiveTypeCheck = (operationName, argumentPosition, expectedType, argumentValue) => {
        /* istanbul ignore if */
        if (typeof argumentValue !== expectedType) {
            throw new TypeError(`Brynja: Expected ${argumentPosition} argument of "${operationName}" operation to be of type ${expectedType}, but received ${typeof argumentValue}`);
        }
    };
    const serializableTypeCheck = (operationName, argumentPosition, argumentValue) => {
        try {
            String(argumentValue);
        }
        catch (_a) {
            /* istanbul ignore next */
            throw new TypeError(`Brynja: Expected ${argumentPosition} argument of "${operationName}" operation to be serializable.`);
        }
    };
    function buildNode(tagType, builder) {
        const ctx = (0, exports.newVNode)({
            tag: tagType,
        });
        let styles = {};
        const builderCtx = {
            style(styleObject) {
                naiveTypeCheck('style', 'first', 'object', styleObject);
                const styleHash = (0, hash.objHash)(styleObject);
                styles[styleHash] = styleObject;
                this.class(styleHash);
                return this;
            },
            on(eventName, handler) {
                naiveTypeCheck('on', 'first', 'string', eventName);
                naiveTypeCheck('on', 'second', 'function', handler);
                if (eventName in ctx.events) {
                    ctx.events[eventName].push(handler);
                }
                else {
                    ctx.events[eventName] = [handler];
                }
                return this;
            },
            child(tagType, builder) {
                naiveTypeCheck('child', 'first', 'string', tagType);
                naiveTypeCheck('child', 'second', 'function', builder);
                const [child, childStyles] = buildNode(tagType, builder);
                ctx.children.push(child);
                styles = Object.assign(Object.assign({}, styles), childStyles);
                return this;
            },
            children(tagType, countOrArray, builder) {
                naiveTypeCheck('child', 'first', 'string', tagType);
                /* istanbul ignore if */
                if (typeof countOrArray !== 'number' && !Array.isArray(countOrArray)) {
                    throw new TypeError(`Brynja: Expected second argument of "child" operation to be of type number or array, but received ${typeof countOrArray}`);
                }
                naiveTypeCheck('child', 'third', 'function', builder);
                const items = typeof countOrArray === 'number'
                    ? Array(countOrArray)
                        .fill(0)
                        .map((_, i) => i)
                    : countOrArray;
                const count = items.length;
                for (let __i = 0; __i < count; __i++) {
                    const [child, childStyles] = buildNode(tagType, (_) => builder(_, items[__i]));
                    ctx.children.push(child);
                    styles = Object.assign(Object.assign({}, styles), childStyles);
                }
                return this;
            },
            when(booleanExpression, then_builder, else_builder) {
                naiveTypeCheck('when', 'first', 'boolean', booleanExpression);
                naiveTypeCheck('when', 'second', 'function', then_builder);
                if (else_builder) {
                    naiveTypeCheck('when', 'third', 'function', else_builder);
                }
                if (booleanExpression) {
                    then_builder(this);
                }
                else if (else_builder) {
                    else_builder(this);
                }
                return this;
            },
            while(predicate, builder) {
                naiveTypeCheck('while', 'first', 'function', predicate);
                naiveTypeCheck('while', 'second', 'function', builder);
                for (let i = 0; predicate(i); i++) {
                    builder(this, i);
                }
                return this;
            },
            do(...builders) {
                builders.forEach((builder) => {
                    /* istanbul ignore if */
                    if (typeof builder !== 'function') {
                        throw new TypeError(`Brynja: Expected all arguments of "do" operation to be functions, but received ${typeof builder}`);
                    }
                    builder(this);
                });
                return this;
            },
            value(value) {
                ctx.value = value;
                return this;
            },
            text(value) {
                serializableTypeCheck('text', 'first', value);
                ctx.text = String(value);
                return this;
            },
            prop(key, value) {
                naiveTypeCheck('prop', 'first', 'string', key);
                serializableTypeCheck('prop', 'second', value);
                ctx.props[key] = String(value);
                return this;
            },
            id(value) {
                naiveTypeCheck('id', 'first', 'string', value);
                ctx.props.id = value;
                return this;
            },
            class(...valuesArr) {
                valuesArr.forEach((className) => {
                    /* istanbul ignore if */
                    if (typeof className !== 'string') {
                        throw new TypeError(`Brynja: Expected all arguments of "class" operation to be strings, but received ${typeof className}`);
                    }
                });
                if (!('class' in ctx.props)) {
                    ctx.props.class = valuesArr.join(' ');
                }
                else {
                    ctx.props.class = [...ctx.props.class.split(' '), ...valuesArr].join(' ');
                }
                return this;
            },
            name(value) {
                naiveTypeCheck('name', 'first', 'string', value);
                ctx.props.name = value;
                return this;
            },
            peek(callback) {
                naiveTypeCheck('peek', 'first', 'function', callback);
                function ctxProxy(ctx) {
                    return {
                        tag: ctx.tag,
                        text: ctx.text,
                        value: ctx.value,
                        props: ctx.props,
                        events: ctx.events,
                        children: new Proxy([], {
                            get: (__, key) => {
                                /* istanbul ignore else */
                                if (key === 'length') {
                                    return ctx.children.length;
                                }
                                else if (!isNaN(parseFloat(key.toString()))) {
                                    return ctxProxy(ctx.children[key]);
                                }
                                else {
                                    throw new Error('Brynja: Illegal operation');
                                }
                            },
                        }),
                    };
                }
                callback(ctxProxy(ctx));
                return this;
            },
        };
        builder(builderCtx);
        return [ctx, styles];
    }
    exports.buildNode = buildNode;
    });

    var renderNode_1 = createCommonjsModule(function (module, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.renderNode = void 0;
    function renderNode(node) {
        const elem = document.createElement(node.tag);
        if (node.value) {
            // @ts-ignore
            elem.value = node.value;
            elem.setAttribute('value', '' + node.value);
        }
        if (node.text !== '') {
            const $text = document.createTextNode(node.text);
            elem.appendChild($text);
        }
        Object.keys(node.props).forEach((prop) => {
            elem.setAttribute(prop, node.props[prop]);
        });
        Object.keys(node.events).forEach((event) => {
            // @ts-ignore
            elem[`on${event}`] = (e) => {
                node.events[event].forEach((cb) => {
                    cb(e);
                });
            };
        });
        node.children.forEach((node) => {
            elem.appendChild(renderNode(node));
        });
        return elem;
    }
    exports.renderNode = renderNode;
    });

    var paramCase_1 = createCommonjsModule(function (module, exports) {
    /**
     * Extracted from source package because it included "tslib" as a dependency
     * "tslib" ended up taking about ~40% of the resulting package size of brynja
     * Source package: https://github.com/blakeembrey/change-case
     * Source license:
     * The MIT License (MIT)
     *
     * Copyright (c) 2014 Blake Embrey (hello@blakeembrey.com)
     *
     * Permission is hereby granted, free of charge, to any person obtaining a copy
     * of this software and associated documentation files (the "Software"), to deal
     * in the Software without restriction, including without limitation the rights
     * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
     * copies of the Software, and to permit persons to whom the Software is
     * furnished to do so, subject to the following conditions:
     *
     * The above copyright notice and this permission notice shall be included in
     * all copies or substantial portions of the Software.
     *
     * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
     * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
     * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
     * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
     * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
     * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
     * THE SOFTWARE.
     */
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.paramCase = void 0;
    // Support camel case ("camelCase" -> "camel Case" and "CAMELCase" -> "CAMEL Case").
    const DEFAULT_SPLIT_REGEXP = [/([a-z0-9])([A-Z])/g, /([A-Z])([A-Z][a-z])/g];
    // Remove all non-word characters.
    const DEFAULT_STRIP_REGEXP = /[^A-Z0-9]+/gi;
    const replace = (input, re, value) => {
        if (re instanceof RegExp)
            return input.replace(re, value);
        return re.reduce((input, re) => input.replace(re, value), input);
    };
    const paramCase = (input) => {
        const splitRegexp = DEFAULT_SPLIT_REGEXP;
        const stripRegexp = DEFAULT_STRIP_REGEXP;
        const transform = (v) => v.toLowerCase();
        const delimiter = '-';
        const result = replace(replace(input, splitRegexp, '$1\0$2'), stripRegexp, '\0');
        let start = 0;
        let end = result.length;
        // Trim the delimiter from around the output string.
        while (result.charAt(start) === '\0')
            start++;
        while (result.charAt(end - 1) === '\0')
            end--;
        // Transform each token independently.
        return result.slice(start, end).split('\0').map(transform).join(delimiter);
    };
    exports.paramCase = paramCase;
    });

    var renderStyles = createCommonjsModule(function (module, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.renderStyle = void 0;

    function renderStyle(styles) {
        const renderedStyles = Object.keys(styles).reduce((res, className) => {
            const allSelectors = Object.keys(styles[className]).reduce((res, key) => {
                if (key.startsWith(':')) {
                    // Extract pseudoClasses
                    res[className + key] = styles[className][key];
                }
                else {
                    // Pass the property along
                    res[className] = Object.assign(Object.assign({}, res[className]), { [key]: styles[className][key] });
                }
                return res;
            }, {});
            const renderStyleObject = (className, styleObj) => {
                const properties = Object.keys(styleObj).map((k) => `${(0, paramCase_1.paramCase)(k)}: ${styleObj[k]};`);
                return `.${className}{${properties.join('')}}`;
            };
            // Render all styles for the current className (including pseudo selectors)
            Object.keys(allSelectors).forEach((selector) => {
                res += renderStyleObject(selector, allSelectors[selector]);
            });
            return res;
        }, '');
        return renderedStyles;
    }
    exports.renderStyle = renderStyle;
    });

    var updateNode_1 = createCommonjsModule(function (module, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.updateNode = void 0;

    const TEXT_NODE = 3; // https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
    function updateNode(newNode, oldNode, elem) {
        if (newNode.tag.toLowerCase() !== oldNode.tag.toLowerCase()) {
            // Different tags requires a re-render
            const newElem = (0, renderNode_1.renderNode)(newNode);
            elem.replaceWith(newElem);
        }
        // #region Update value
        if (newNode.value && newNode.value !== oldNode.value) {
            // @ts-ignore
            elem.value = newNode.value;
            elem.setAttribute('value', '' + newNode.value);
        }
        else if (newNode.value !== oldNode.value) {
            // @ts-ignore
            elem.value = undefined;
            elem.removeAttribute('value');
        }
        // #endregion
        // #region Update text node
        /* istanbul ignore else */ // there is no else statement, and istanbul doesn't like it
        if (oldNode.text === newNode.text) ;
        else if (oldNode.text === '' && newNode.text !== '') {
            // Add text
            const $text = document.createTextNode(newNode.text);
            elem.appendChild($text);
        }
        else if (oldNode.text !== '') {
            /* istanbul ignore if */
            if (elem.firstChild === null || elem.firstChild.nodeType !== TEXT_NODE) {
                throw new Error('Brynja: Unexpected "none text node" as first child of element: ' + elem);
            }
            if (newNode.text === '') {
                // Remove text
                elem.firstChild.remove();
            }
            else if (newNode.text !== '') {
                // Update text
                elem.firstChild.textContent = newNode.text;
            }
        }
        // #endregion
        // #region Update props
        for (const prop in oldNode.props) {
            if (prop in newNode.props) {
                continue;
            }
            // @ts-ignore
            elem.removeAttribute(prop);
        }
        for (const prop in newNode.props) {
            if (oldNode.props[prop] === newNode.props[prop]) {
                continue;
            }
            // @ts-ignore
            elem.setAttribute(prop, newNode.props[prop]);
        }
        // #endregion
        // #region Update events
        for (const event in oldNode.events) {
            if (event in newNode.events) {
                continue;
            }
            // @ts-ignore
            elem[`on${event}`] = undefined;
        }
        for (const event in newNode.events) {
            // @ts-ignore
            elem[`on${event}`] = (e) => {
                newNode.events[event].forEach((cb) => {
                    cb(e);
                });
            };
        }
        // #endregion
        // #region Update children
        for (let i = 0; i < newNode.children.length; i++) {
            if (i < oldNode.children.length) {
                // Updated elements compared to previous nodeTree
                updateNode(newNode.children[i], oldNode.children[i], elem.children.item(i));
            }
            else {
                // Create new elements
                elem.appendChild((0, renderNode_1.renderNode)(newNode.children[i]));
            }
        }
        const firstInvalidIndex = newNode.children.length;
        const elementsToRemove = elem.children.length - firstInvalidIndex;
        for (let i = 0; i < elementsToRemove; i++) {
            // Remove extra elements
            const childElement = elem.children.item(firstInvalidIndex);
            /* istanbul ignore if */
            if (childElement === null) {
                throw new Error(`Brynja: Unexpected invalid child element while removing excess children from element: ${elem}`);
            }
            childElement.remove();
        }
        // #endregion
    }
    exports.updateNode = updateNode;
    });

    var renderer = createCommonjsModule(function (module, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Renderer = void 0;




    function Renderer(config) {
        let initialRender = true;
        let oldRootNode = null;
        return {
            render(rootBuilder) {
                const [rootNode, styles] = (0, builder.buildNode)(config.rootElement.tagName.toLowerCase(), rootBuilder);
                // Append styles if needed
                if (Object.keys(styles).length > 0) {
                    rootNode.children.push((0, builder.newVNode)({
                        tag: 'style',
                        text: (0, renderStyles.renderStyle)(styles),
                        props: {
                            type: 'text/css',
                        },
                    }));
                }
                // Render / Update HTML
                if (initialRender) {
                    initialRender = false;
                    const newRoot = (0, renderNode_1.renderNode)(rootNode);
                    config.rootElement.replaceWith(newRoot);
                    config.rootElement = newRoot;
                }
                else {
                    (0, updateNode_1.updateNode)(rootNode, oldRootNode, config.rootElement);
                }
                // Update refs for next render
                oldRootNode = rootNode;
            },
        };
    }
    exports.Renderer = Renderer;
    });

    var events = createCommonjsModule(function (module, exports) {
    // Events: https://www.w3schools.com/tags/ref_eventattributes.asp
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Events = void 0;
    (function (Events) {
        (function (Mouse) {
            Mouse["Click"] = "click";
            Mouse["DoubleClick"] = "dblclick";
            Mouse["Down"] = "mousedown";
            Mouse["Up"] = "mouseup";
            Mouse["Move"] = "mousemove";
            Mouse["Out"] = "mouseout";
            Mouse["Over"] = "mouseover";
            Mouse["Wheel"] = "wheel";
        })(Events.Mouse || (Events.Mouse = {}));
        (function (Keyboard) {
            Keyboard["Down"] = "keydown";
            Keyboard["Up"] = "keyup";
            Keyboard["Press"] = "keypress";
        })(Events.Keyboard || (Events.Keyboard = {}));
        (function (Drag) {
            Drag["Drag"] = "drag";
            Drag["End"] = "dragend";
            Drag["Enter"] = "dragenter";
            Drag["Leave"] = "dragleave";
            Drag["Over"] = "dragover";
            Drag["Start"] = "dragstart";
            Drag["Drop"] = "drop";
            Drag["Scroll"] = "scroll";
        })(Events.Drag || (Events.Drag = {}));
        (function (Clipboard) {
            Clipboard["Copy"] = "copy";
            Clipboard["Cut"] = "cut";
            Clipboard["Paste"] = "paste";
        })(Events.Clipboard || (Events.Clipboard = {}));
    })(exports.Events || (exports.Events = {}));
    });

    var createComponent_1 = createCommonjsModule(function (module, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.createComponent = void 0;
    /**
     * Usage of this function is 100% optional.
     * It serves ONLY to add type support for brynja operations through typescript and JSDocs.
     * @param {(...args: any[]) => BuilderCB} componentConstructor
     */
    const createComponent = (componentConstructor) => componentConstructor;
    exports.createComponent = createComponent;
    });

    var createStyles_1 = createCommonjsModule(function (module, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.createStyles = void 0;
    /**
     * Usage of this function is 100% optional.
     * It serves ONLY to add type support for brynja operations through typescript and JSDocs.
     * @param {IStyleObject} styles
     */
    const createStyles = (styles) => styles;
    exports.createStyles = createStyles;
    });

    var brynja = createCommonjsModule(function (module, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.render = exports.createStyles = exports.createComponent = exports.Renderer = exports.Events = void 0;


    Object.defineProperty(exports, "Events", { enumerable: true, get: function () { return events.Events; } });
    var renderer_2 = renderer;
    Object.defineProperty(exports, "Renderer", { enumerable: true, get: function () { return renderer_2.Renderer; } });

    Object.defineProperty(exports, "createComponent", { enumerable: true, get: function () { return createComponent_1.createComponent; } });

    Object.defineProperty(exports, "createStyles", { enumerable: true, get: function () { return createStyles_1.createStyles; } });
    const defaultRenderer = (() => {
        let default_renderer = null;
        return () => {
            if (default_renderer === null) {
                // This makes sure the dom is ready when the Renderer is constructed.
                const rootElement = document.getElementById('root');
                /* istanbul ignore if */
                if (rootElement === null) {
                    throw new Error('Brynja: Unable to locate element with id "root"');
                }
                default_renderer = (0, renderer.Renderer)({
                    rootElement,
                });
            }
            return default_renderer;
        };
    })();
    const render = (rootBuilder) => defaultRenderer().render(rootBuilder);
    exports.render = render;
    });

    var useFeature = function (key) {
        try {
            if (chrome[key]) {
                return chrome[key];
            }
        }
        catch (_a) { }
        try {
            //@ts-ignore
            if (browser[key]) {
                //@ts-ignore
                return browser[key];
            }
        }
        catch (_b) { }
        try {
            //@ts-ignore
            if (window[key]) {
                //@ts-ignore
                return window[key];
            }
        }
        catch (_c) { }
    };

    var storage = useFeature('storage');
    var runtime = useFeature('runtime');
    useFeature('tabs');

    var sensitiveData = { hookURL: null };
    var omitSensitiveData = function (obj) { return Object.keys(obj)
        .filter(function (k) { return !(k in sensitiveData); })
        .reduce(function (res, k) {
        var _a;
        return (__assign(__assign({}, res), (_a = {}, _a[k] = obj[k], _a)));
    }, {}); };

    var limitStoredLogs = function (numberOfLogsToKeep) { return __awaiter(void 0, void 0, void 0, function () {
        var logs, logsToKeep;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, storage.local.get('logs')];
                case 1:
                    logs = (_a.sent()).logs;
                    logsToKeep = logs.slice(Math.max(0, logs.length - numberOfLogsToKeep));
                    return [2 /*return*/, storage.local.set({
                            logs: logsToKeep
                        })];
            }
        });
    }); };
    var processMessageParts = function (parts) { return parts.map(function (v) {
        if (typeof v === 'object') {
            v = omitSensitiveData(v);
            try {
                return JSON.stringify(v);
            }
            catch (_a) { }
        }
        return String(v);
    }).join(' '); };
    var storeLog = function (log) { return __awaiter(void 0, void 0, void 0, function () {
        var logs;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, storage.local.get('logs')];
                case 1:
                    logs = (_a.sent()).logs;
                    return [4 /*yield*/, storage.local.set({
                            logs: __spreadArray(__spreadArray([], (logs !== null && logs !== void 0 ? logs : []), true), [log], false)
                        })];
                case 2:
                    _a.sent();
                    limitStoredLogs(100);
                    return [2 /*return*/];
            }
        });
    }); };
    var useLogger = function (source) { return ({
        info: function () {
            var messageParts = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                messageParts[_i] = arguments[_i];
            }
            return storeLog({
                type: 'info',
                source: source,
                timestamp: Date.now(),
                content: processMessageParts(messageParts)
            });
        },
        error: function () {
            var messageParts = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                messageParts[_i] = arguments[_i];
            }
            return storeLog({
                type: 'error',
                source: source,
                timestamp: Date.now(),
                content: processMessageParts(messageParts)
            });
        },
        warn: function () {
            var messageParts = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                messageParts[_i] = arguments[_i];
            }
            return storeLog({
                type: 'warning',
                source: source,
                timestamp: Date.now(),
                content: processMessageParts(messageParts)
            });
        }
    }); };

    var logger = useLogger('popupPage');
    var openOptionsPage = function () {
        logger.info('Opening options page');
        // Clicking the extension icon should open the options page
        runtime.openOptionsPage(function () {
            window.close();
        });
    };
    var update = function () {
        storage.sync.get(function (data) {
            logger.info('Rendering', data);
            brynja.render(function (_) { return _
                .child('center', function (_) { return _
                .child('button', function (_) { return _
                .text('Enable')
                .style({
                width: '200px'
            })
                .when(!data.disabled, function (_) { return _
                .prop('disabled', 'true'); })
                .on('click', function () {
                logger.info('Extension enabled');
                storage.sync.set(__assign(__assign({}, data), { disabled: false }));
                update();
            }); })
                .child('button', function (_) { return _
                .text('Disable')
                .style({
                width: '200px'
            })
                .when(data.disabled, function (_) { return _
                .prop('disabled', 'true'); })
                .on('click', function () {
                logger.info('Extension disabled');
                storage.sync.set(__assign(__assign({}, data), { disabled: true }));
                update();
            }); })
                .child('hr', function (_) { return _; })
                .child('button', function (_) { return _
                .text('Configure')
                .style({
                width: '200px'
            })
                .on('click', function () {
                openOptionsPage();
            }); }); }); });
        });
    };
    update();

})();
